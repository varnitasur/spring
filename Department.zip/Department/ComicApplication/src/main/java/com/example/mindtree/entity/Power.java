package com.example.mindtree.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Power {
	
	@Id
	private int powerId;
	private String powerName;
	private int powerDamage;
	@ManyToOne(cascade = CascadeType.ALL)
	private SuperHero superHero;
	public Power() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Power(int powerId, String powerName, int powerDamage, SuperHero superHero) {
		super();
		this.powerId = powerId;
		this.powerName = powerName;
		this.powerDamage = powerDamage;
		this.superHero = superHero;
	}
	public int getPowerId() {
		return powerId;
	}
	public void setPowerId(int powerId) {
		this.powerId = powerId;
	}
	public String getPowerName() {
		return powerName;
	}
	public void setPowerName(String powerName) {
		this.powerName = powerName;
	}
	public int getPowerDamage() {
		return powerDamage;
	}
	public void setPowerDamage(int powerDamage) {
		this.powerDamage = powerDamage;
	}
	public SuperHero getSuperHero() {
		return superHero;
	}
	public void setSuperHero(SuperHero superHero) {
		this.superHero = superHero;
	}
		
	
	

}
