package com.example.mindtree.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mindtree.dto.ComicDTO;
import com.example.mindtree.dto.SuperHeroDTO;
import com.example.mindtree.exception.serviceexception.ServiceException;
import com.example.mindtree.service.ComicService;
@RestController
public class DemoController {

	@Autowired
	ComicService comicService;
	
	public String insertComic(@RequestBody ComicDTO comicDto) {
		String m=comicService.insertedComicDetails(comicDto);
		return "inserted";
		
	}
	
	public Set<SuperHeroDTO> getSuperHero(){
		return comicService.getSuperHeros();
	}
	
	public int getTotalDamage(@PathVariable int superHeroId) throws ServiceException {
		return comicService.getTotalDamage(superHeroId);
		
	}
}
