package com.example.mindtree.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class SuperHero {
	
	@Id
	private int superHeroId;
	private String superHeroName;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "superHero")
	private List<Power> powerList;
	@ManyToOne(cascade = CascadeType.ALL)
	private Comic comic;
	
	public SuperHero() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SuperHero(int superHeroId, String superHeroName, List<Power> powerList, Comic comic) {
		super();
		this.superHeroId = superHeroId;
		this.superHeroName = superHeroName;
		this.powerList = powerList;
		this.comic = comic;
	}
	public int getSuperHeroId() {
		return superHeroId;
	}
	public void setSuperHeroId(int superHeroId) {
		this.superHeroId = superHeroId;
	}
	public String getSuperHeroName() {
		return superHeroName;
	}
	public void setSuperHeroName(String superHeroName) {
		this.superHeroName = superHeroName;
	}
	public List<Power> getPowerList() {
		return powerList;
	}
	public void setPowerList(List<Power> powerList) {
		this.powerList = powerList;
	}
	public Comic getComic() {
		return comic;
	}
	public void setComic(Comic comic) {
		this.comic = comic;
	}
	
	
	
	

}
