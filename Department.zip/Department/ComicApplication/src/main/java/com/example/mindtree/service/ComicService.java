package com.example.mindtree.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.mindtree.dto.ComicDTO;
import com.example.mindtree.dto.SuperHeroDTO;
import com.example.mindtree.exception.serviceexception.ServiceException;

@Service
public interface ComicService {

	String insertedComicDetails(ComicDTO comicDto);

	Set<SuperHeroDTO> getSuperHeros();

	int getTotalDamage(int superHeroId) throws ServiceException;

}
