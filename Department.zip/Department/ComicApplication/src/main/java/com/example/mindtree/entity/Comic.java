package com.example.mindtree.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Comic {
	
	@Id
	private int comicId;
	private String comicName;
	private String comicUniverse;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "comic")
	Set<SuperHero> superHeroSet;
	public Comic() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comic(int comicId, String comicName, String comicUniverse, Set<SuperHero> superHeroSet) {
		super();
		this.comicId = comicId;
		this.comicName = comicName;
		this.comicUniverse = comicUniverse;
		this.superHeroSet = superHeroSet;
	}
	public int getComicId() {
		return comicId;
	}
	public void setComicId(int comicId) {
		this.comicId = comicId;
	}
	public String getComicName() {
		return comicName;
	}
	public void setComicName(String comicName) {
		this.comicName = comicName;
	}
	public String getComicUniverse() {
		return comicUniverse;
	}
	public void setComicUniverse(String comicUniverse) {
		this.comicUniverse = comicUniverse;
	}
	public Set<SuperHero> getSuperHeroSet() {
		return superHeroSet;
	}
	public void setSuperHeroSet(Set<SuperHero> superHeroSet) {
		this.superHeroSet = superHeroSet;
	}
	
	

}
