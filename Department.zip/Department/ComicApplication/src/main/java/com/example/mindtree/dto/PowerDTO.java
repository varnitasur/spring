package com.example.mindtree.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class PowerDTO {
	
	private int powerId;
	private String powerName;
	private int powerDamage;
	@JsonIgnoreProperties("powerList")
	private SuperHeroDTO superHero;
	public int getPowerId() {
		return powerId;
	}
	public void setPowerId(int powerId) {
		this.powerId = powerId;
	}
	public String getPowerName() {
		return powerName;
	}
	public void setPowerName(String powerName) {
		this.powerName = powerName;
	}
	public int getPowerDamage() {
		return powerDamage;
	}
	public void setPowerDamage(int powerDamage) {
		this.powerDamage = powerDamage;
	}
	public SuperHeroDTO getSuperHero() {
		return superHero;
	}
	public void setSuperHero(SuperHeroDTO superHero) {
		this.superHero = superHero;
	}
	@Override
	public String toString() {
		return "PowerDTO [powerId=" + powerId + ", powerName=" + powerName + ", powerDamage=" + powerDamage
				+ ", superHero=" + superHero + "]";
	}
	
}
