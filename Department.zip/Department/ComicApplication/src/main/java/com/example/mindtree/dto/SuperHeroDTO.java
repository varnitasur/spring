package com.example.mindtree.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class SuperHeroDTO {
	
	private int superHeroId;
	private String superHeroName;
	@JsonIgnoreProperties("superHero")
	private List<PowerDTO> powerList;
	@JsonIgnoreProperties("superHeroSet")
	private ComicDTO comic;
	public int getSuperHeroId() {
		return superHeroId;
	}
	public void setSuperHeroId(int superHeroId) {
		this.superHeroId = superHeroId;
	}
	public String getSuperHeroName() {
		return superHeroName;
	}
	public void setSuperHeroName(String superHeroName) {
		this.superHeroName = superHeroName;
	}
	public List<PowerDTO> getPowerList() {
		return powerList;
	}
	public void setPowerList(List<PowerDTO> powerList) {
		this.powerList = powerList;
	}
	public ComicDTO getComic() {
		return comic;
	}
	public void setComic(ComicDTO comic) {
		this.comic = comic;
	}
	@Override
	public String toString() {
		return "SuperHeroDTO [superHeroId=" + superHeroId + ", superHeroName=" + superHeroName + ", powerList="
				+ powerList + ", comic=" + comic + "]";
	}
	
	

}
