package com.example.mindtree.service.serviceimpl;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.dto.ComicDTO;
import com.example.mindtree.dto.PowerDTO;
import com.example.mindtree.dto.SuperHeroDTO;
import com.example.mindtree.entity.Comic;
import com.example.mindtree.entity.Power;
import com.example.mindtree.entity.SuperHero;
import com.example.mindtree.exception.serviceexception.ServiceException;
import com.example.mindtree.exception.serviceexception.SuperHeroNotFoundException;
import com.example.mindtree.repository.ComicRepository;
import com.example.mindtree.repository.PowerRepository;
import com.example.mindtree.repository.SuperHeroRepository;
import com.example.mindtree.service.ComicService;

@Service
public class ComicServiceImpl implements ComicService {

	@Autowired
	ComicRepository comicRepose;
	@Autowired
	PowerRepository powerRepose;
	@Autowired
	SuperHeroRepository superHeroRepose;
	
	ModelMapper modelMapper = new ModelMapper();
	
	
	private Comic convertDTOToEntity(ComicDTO comicDto) {
		return modelMapper.map(comicDto,Comic.class);
	}
	
	private Power convertDTOToEntity(PowerDTO powerDto) {
		return modelMapper.map(powerDto,Power.class);
	}
	
	private SuperHero convertDTOToEntity(SuperHeroDTO superHeroDto) {
		return modelMapper.map(superHeroDto,SuperHero.class);
	}
	
	

	private ComicDTO convertEntityToDTO(Comic comic) {
		return modelMapper.map(comic,ComicDTO.class);
	}
	
	private PowerDTO convertEntityToDTO(Power power) {
		return modelMapper.map(power,PowerDTO.class);
	}
	
	private SuperHeroDTO convertEntityToDTO(SuperHero superHero) {
		return modelMapper.map(superHero,SuperHeroDTO.class);
	}
	
	
	
	
	@Override
	public String insertedComicDetails(ComicDTO comicDto) {
		Comic comic =convertDTOToEntity(comicDto);
		comic.getSuperHeroSet().forEach(i->i.setComic(comic));
		comic.getSuperHeroSet().forEach(i->i.getPowerList().forEach(j-> j.setSuperHero(i)));
		comicRepose.save(comic);
		return "inserted";
	}

	@Override
	public Set<SuperHeroDTO> getSuperHeros() {
		int c=0;
		Set<SuperHero> superHeroSet = new HashSet<SuperHero>();
		for (SuperHero superHero : superHeroRepose.findAll()) {
			for (Power power : superHero.getPowerList()) {
				if(power.getPowerName().equalsIgnoreCase("invisibility")) {
					c++;
				}
				if(power.getPowerName().equalsIgnoreCase("flying")) {
					c++;
				}
				if(c==2) {
					superHeroSet.add(superHero);
				}
			}
			
		}
		return superHeroSet.parallelStream().map(p->convertEntityToDTO(p)).collect(Collectors.toSet());
	}

	@Override
	public int getTotalDamage(int superHeroId) throws ServiceException
	{
		int sum=0;
		if(superHeroRepose.existsById(superHeroId)) 
		{
			SuperHero superHero=superHeroRepose.findById(superHeroId).get();
			for (Power power : superHero.getPowerList())
			{
				sum=sum+power.getPowerDamage();
				
			}
		}
			else
			{
				try 
				{
					throw new SuperHeroNotFoundException("Super Hero Id Not Found");
				}catch (SuperHeroNotFoundException e) 
				{
					throw new ServiceException(e);
				}
				
			}
			

		return sum;
	}

}
