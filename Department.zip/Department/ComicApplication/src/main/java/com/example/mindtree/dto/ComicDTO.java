package com.example.mindtree.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ComicDTO {
	
	private int comicId;
	private String comicName;
	private String comicUniverse;
	@JsonIgnoreProperties("comic")
	Set<SuperHeroDTO> superHeroSet;
	public int getComicId() {
		return comicId;
	}
	public void setComicId(int comicId) {
		this.comicId = comicId;
	}
	public String getComicName() {
		return comicName;
	}
	public void setComicName(String comicName) {
		this.comicName = comicName;
	}
	public String getComicUniverse() {
		return comicUniverse;
	}
	public void setComicUniverse(String comicUniverse) {
		this.comicUniverse = comicUniverse;
	}
	public Set<SuperHeroDTO> getSuperHeroSet() {
		return superHeroSet;
	}
	public void setSuperHeroSet(Set<SuperHeroDTO> superHeroSet) {
		this.superHeroSet = superHeroSet;
	}
	@Override
	public String toString() {
		return "ComicDTO [comicId=" + comicId + ", comicName=" + comicName + ", comicUniverse=" + comicUniverse
				+ ", superHeroSet=" + superHeroSet + "]";
	}
	

}
