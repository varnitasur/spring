package com.example.mindtree.service.serviceimpl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.mindtree.dto.ComicDTO;
import com.example.mindtree.dto.PowerDTO;
import com.example.mindtree.dto.SuperHeroDTO;
import com.example.mindtree.entity.Comic;
import com.example.mindtree.entity.Power;
import com.example.mindtree.entity.SuperHero;
import com.example.mindtree.exception.serviceexception.ServiceException;
import com.example.mindtree.repository.ComicRepository;
import com.example.mindtree.repository.SuperHeroRepository;

public class ComicServiceImplTest {

	ModelMapper modelMapper = new ModelMapper();
	
	private ComicDTO convertEntityToDTO(Comic comic) {
		return modelMapper.map(comic,ComicDTO.class);
	}
	
	private PowerDTO convertEntityToDTO(Power power) {
		return modelMapper.map(power,PowerDTO.class);
	}
	
	private SuperHeroDTO convertEntityToDTO(SuperHero superHero) {
		return modelMapper.map(superHero,SuperHeroDTO.class);
	}
	
	@InjectMocks
	ComicServiceImpl comicServiceImpl;
	
	@Mock
	ComicRepository comicRepose;
	
	@Mock
	SuperHeroRepository superHeroRepose;
	
	@Autowired
	MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc=MockMvcBuilders.standaloneSetup(comicServiceImpl).build();
	}


	@Test
	public void testInsertedComicDetails() {
		
		Power power =new Power(1,"flying",4,null);
		List<Power> listPower=new ArrayList<Power>();
		listPower.add(power);
		SuperHero superHero= new SuperHero(1,"devil",listPower,null);
		Set<SuperHero> set= new HashSet<SuperHero>();
		set.add(superHero);
		
		Comic comic= new Comic (1,"angel","vf",set);
		when(comicRepose.save(comic)).thenReturn(comic);
		 
		ComicDTO comicDto= convertEntityToDTO(comic);
		 
		assertEquals(comicServiceImpl.insertedComicDetails(comicDto),"inserted");
		
	}

	@Test
	public void testGetSuperHeros() {
		List<Power> listPower1= new ArrayList<Power>();
		List<Power> listPower2= new ArrayList<Power>();
		
		
		Power power1= new Power(1,"flying",5,null);
		Power power2= new Power(1,"fire",5,null);
		Power power3= new Power(1,"invisiblity",5,null);
		
		listPower1.add(power1);
		listPower1.add(power3);
		listPower2.add(power1);
		listPower2.add(power2);
		
		SuperHero superHero1= new SuperHero(1,"devil",listPower1,null);
		SuperHero superHero2= new SuperHero(1,"angel",listPower2,null);
		
		List<SuperHero> listSuper=new ArrayList<SuperHero>();
		listSuper.add(superHero1);
		listSuper.add(superHero2);
		
		when(superHeroRepose.findAll()).thenReturn(listSuper);
		
		assertEquals(comicServiceImpl.getSuperHeros().size(),1);
		
	}

	@Test
	public void testGetTotalDamage() throws ServiceException {
		
		Power power =new Power(1,"flying",4,null);
		List<Power> listPower=new ArrayList<Power>();
		listPower.add(power);
		SuperHero superHero= new SuperHero(1,"devil",listPower,null);
		
		when(superHeroRepose.existsById(superHero.getSuperHeroId())).thenReturn(true);
		when(superHeroRepose.getOne(superHero.getSuperHeroId())).thenReturn(superHero);
		
		assertEquals(comicServiceImpl.getTotalDamage(1),9);
		
		
	}

}
