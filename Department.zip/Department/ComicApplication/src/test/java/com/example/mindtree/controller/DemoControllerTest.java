package com.example.mindtree.controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.mindtree.dto.SuperHeroDTO;
import com.example.mindtree.entity.Power;
import com.example.mindtree.entity.SuperHero;
import com.example.mindtree.service.ComicService;

public class DemoControllerTest {
	
	ModelMapper modelMapper= new ModelMapper();

	private SuperHeroDTO convertEntityToDTO(SuperHero superHero) {
		return modelMapper.map(superHero,SuperHeroDTO.class);
	}
	@InjectMocks
	DemoController comicController;
	
	@Mock
	ComicService comicService;
	
	@Autowired
	MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc=MockMvcBuilders.standaloneSetup(comicController).build();
	}


	

	@Test
	public void testInsertComic() {
		
	}
	
	@Test
	public void testGetSuperHero() {
		Set<SuperHero> superHeroSet= new HashSet<SuperHero>();
		Set<SuperHero> superHeroSet1= new HashSet<SuperHero>();
		List<Power> listPower1= new ArrayList<Power>();
		List<Power> listPower2= new ArrayList<Power>();
		
		
		Power power1= new Power(1,"flying",5,null);
		Power power2= new Power(1,"fire",5,null);
		Power power3= new Power(1,"invisiblity",5,null);
		
		listPower1.add(power1);
		listPower1.add(power3);
		listPower2.add(power1);
		listPower2.add(power2);
		
		SuperHero superHero1= new SuperHero(1,"devil",listPower1,null);
		SuperHero superHero2= new SuperHero(1,"angel",listPower2,null);
		
		superHeroSet.add(superHero1);
		superHeroSet.add(superHero2);
		superHeroSet1.add(superHero1);
		
		Set<SuperHeroDTO> superHeroDtoSet=superHeroSet.stream().map(i->convertEntityToDTO(i)).collect(Collectors.toSet());
		List<SuperHero> listSuper=new ArrayList<SuperHero>();
		Set<SuperHeroDTO> superHeroDtoSet1=superHeroSet1.stream().map(i->convertEntityToDTO(i)).collect(Collectors.toSet());
		
		listSuper.add(superHero2);
		listSuper.add(superHero1);
		
		when(comicService.getSuperHeros()).thenReturn(superHeroDtoSet1);
		
		assertEquals(comicController.getSuperHero().size(),2);
		
		
		
	}

	
	@Test
	public void testGetTotalDamage() {
		
	}

}
