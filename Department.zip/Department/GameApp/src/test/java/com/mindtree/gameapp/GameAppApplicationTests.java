package com.mindtree.gameapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
