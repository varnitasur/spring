package com.example.demo.exception;

public class ErrorConstant {

	public ErrorConstant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static final String NoSuchVenueFound=" no venue is present";
	public static final String NoSuchPrizeFound=" no prize is present";

}
