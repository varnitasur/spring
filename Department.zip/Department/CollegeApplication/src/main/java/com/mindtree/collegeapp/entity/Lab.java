package com.mindtree.collegeapp.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
@Entity
public class Lab {
	
	@Id
	private int labId;
	private String labName;
	@ManyToOne
	private College college;
	@ManyToMany
	@JoinTable(name = "lab_List", joinColumns = @JoinColumn(name = "lab_id"),  inverseJoinColumns = @JoinColumn(name = "student_id"))
	private List<Student> studentList;
	public Lab() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Lab(int labId, String labName, College college, List<Student> studentList) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.college = college;
		this.studentList = studentList;
	}
	public int getLabId() {
		return labId;
	}
	public void setLabId(int labId) {
		this.labId = labId;
	}
	public String getLabName() {
		return labName;
	}
	public void setLabName(String labName) {
		this.labName = labName;
	}
	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

	
}
