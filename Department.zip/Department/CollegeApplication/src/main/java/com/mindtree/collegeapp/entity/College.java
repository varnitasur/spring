package com.mindtree.collegeapp.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class College {

	@Id
	private int CollegeId;
	private String CollegeName;
	private int capacity;
	private String location;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "college")
	private List<Lab> labs;
	public College() {
		super();
		// TODO Auto-generated constructor stub
	}
	public College(int collegeId, String collegeName, int capacity, String location, List<Lab> labs) {
		super();
		CollegeId = collegeId;
		CollegeName = collegeName;
		this.capacity = capacity;
		this.location = location;
		this.labs = labs;
	}
	public int getCollegeId() {
		return CollegeId;
	}
	public void setCollegeId(int collegeId) {
		CollegeId = collegeId;
	}
	public String getCollegeName() {
		return CollegeName;
	}
	public void setCollegeName(String collegeName) {
		CollegeName = collegeName;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<Lab> getLabs() {
		return labs;
	}
	public void setLabs(List<Lab> labs) {
		this.labs = labs;
	}
	
}
