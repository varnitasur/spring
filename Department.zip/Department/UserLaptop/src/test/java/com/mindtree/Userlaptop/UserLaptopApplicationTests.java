package com.mindtree.Userlaptop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLaptopApplicationTests {

	@Test
	void contextLoads() {
	}

}
