package com.mindtree.Userlaptop.service;

import org.springframework.stereotype.Service;

import com.mindtree.Userlaptop.entity.User;
@Service
public interface UserService {

	String addUser(User user);

}
