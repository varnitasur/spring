package com.mindtree.Userlaptop.DemoController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Userlaptop.entity.User;
import com.mindtree.Userlaptop.service.UserService;
@RestController
public class Controller {
	
	@Autowired
	UserService service;
	
	public String addUser(@RequestBody User user ) {
		String m=service.addUser(user);
		return m;
		
	}

}
