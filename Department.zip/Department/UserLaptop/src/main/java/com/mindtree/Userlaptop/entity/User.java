package com.mindtree.Userlaptop.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class User {

	@Id
	private int UserId;
	private String UserName;
	@OneToMany(cascade = CascadeType.ALL ,mappedBy = "user")
	private Set<Laptop> laptops;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int userId, String userName, Set<Laptop> laptops) {
		super();
		UserId = userId;
		UserName = userName;
		this.laptops = laptops;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public Set<Laptop> getLaptops() {
		return laptops;
	}
	public void setLaptops(Set<Laptop> laptops) {
		this.laptops = laptops;
	}
	
}
