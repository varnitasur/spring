package com.mindtree.Userlaptop.service.serviceImpl;

import com.mindtree.Userlaptop.entity.User;
import com.mindtree.Userlaptop.service.UserService;

public class UserServiceImpl implements UserService {

	@Override
	public String addUser(User user) {
		
		return null;
	}

}
