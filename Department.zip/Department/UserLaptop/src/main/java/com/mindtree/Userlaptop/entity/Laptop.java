package com.mindtree.Userlaptop.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Laptop {
	@Id
	private int LaptopId;
	private String LaptopName;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "laptop")
	private Set<Movie> movies;
	@ManyToOne(cascade = CascadeType.ALL)
	private User user;
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Laptop(int laptopId, String laptopName, Set<Movie> movies, User user) {
		super();
		LaptopId = laptopId;
		LaptopName = laptopName;
		this.movies = movies;
		this.user = user;
	}
	public int getLaptopId() {
		return LaptopId;
	}
	public void setLaptopId(int laptopId) {
		LaptopId = laptopId;
	}
	public String getLaptopName() {
		return LaptopName;
	}
	public void setLaptopName(String laptopName) {
		LaptopName = laptopName;
	}
	public Set<Movie> getMovies() {
		return movies;
	}
	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	

}
