package com.example.demo.entity;

public class Hotel {

	private int hotelId;
	private String hotelName;
	
	
}
