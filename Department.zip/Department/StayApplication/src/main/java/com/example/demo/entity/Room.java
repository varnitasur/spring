package com.example.demo.entity;

public class Room {

	private int roomId;
	private String roomType;
	
}
