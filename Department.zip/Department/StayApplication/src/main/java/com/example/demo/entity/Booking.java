package com.example.demo.entity;

public class Booking {
	
	private int bookingId;
	private String bookingType;
	private String bookindDate;

}
