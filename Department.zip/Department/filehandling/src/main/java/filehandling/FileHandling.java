package filehandling;

import java.io.File;
import java.io.IOException;

public class FileHandling {
	
	public static void main(String[] args) {
		try {
		File myobj=new File("D:\\filehandle\\file2.txt");
		if(myobj.createNewFile())
		{
			System.out.println("File created"+myobj.getName());
		}
		else {
			System.out.println("File already exists");
		}
		}catch(IOException e)
		{
			System.out.println("an error occured");
			
		}
		
	}

}
