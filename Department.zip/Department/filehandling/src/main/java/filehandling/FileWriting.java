package filehandling;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriting {

	public static void main(String[] args) {
		try {
			FileWriter mywriter = new FileWriter("D:\\filehandle\\file2.txt");
			mywriter.write("java is the prominent language");
			mywriter.close();
			System.out.println("successfully writen");

		} catch (IOException e) {
			System.out.println("an error occured");

		}

	}

}
