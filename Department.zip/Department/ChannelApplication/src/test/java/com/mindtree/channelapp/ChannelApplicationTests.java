package com.mindtree.channelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChannelApplicationTests {

	@Test
	void contextLoads() {
	}

}
