package com.mindtree.channelapp.exception.errorconstant;

public class ErrorConstant {
	
	public final static String NoSuchChannelGroupFound="No Such Channel Group Found";
	public final static String NoSuchChannelFound="No Such Channel Found";
			
}
