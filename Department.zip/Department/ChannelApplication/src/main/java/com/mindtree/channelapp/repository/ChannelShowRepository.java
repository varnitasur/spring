package com.mindtree.channelapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.channelapp.entity.ChannelShow;

public interface ChannelShowRepository extends JpaRepository<ChannelShow, Integer> {

}
