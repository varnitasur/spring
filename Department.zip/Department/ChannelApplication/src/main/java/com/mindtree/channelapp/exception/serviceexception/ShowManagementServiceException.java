package com.mindtree.channelapp.exception.serviceexception;

import com.mindtree.channelapp.exception.controllerexception.ShowMangementException;

public class ShowManagementServiceException extends ShowMangementException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShowManagementServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShowManagementServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ShowManagementServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ShowManagementServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ShowManagementServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
