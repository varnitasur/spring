package com.example.demo.dto;

import java.util.List;

public class AlbumDTO {
	
	private int albumId;
	private String albumName;
	private List<SongDTO> songList;
	
	public int getAlbumId() {
		return albumId;
	}
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public List<SongDTO> getSongList() {
		return songList;
	}
	public void setSongList(List<SongDTO> songList) {
		this.songList = songList;
	}
	
	

}
