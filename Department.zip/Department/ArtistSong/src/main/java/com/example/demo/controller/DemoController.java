package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.AlbumDTO;
import com.example.demo.dto.SongDTO;
import com.example.demo.service.ArtistSongService;

@RestController
public class DemoController {
	
	@Autowired
	ArtistSongService service;
	
	@PostMapping("/insert")
	public String insertdata(@RequestBody SongDTO songDto) {
		return service.addSong(songDto);
	}
	@GetMapping("/get")
	public List<AlbumDTO> getallAlbums() {
		return service.getallAlbums();
	}
	@GetMapping("/get/{songId}")
	public List<SongDTO> getData(@PathVariable int songId){
		List<SongDTO> songs=service.getAllSongs(songId);
		return songs;
	}
	@GetMapping("/getCount/{albumId}")
	public int getCount(@PathVariable int albumId) {
		return service.getCountofSongs(albumId);
	}

}
