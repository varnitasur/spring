package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dto.AlbumDTO;
import com.example.demo.dto.SongDTO;

@Service
public interface ArtistSongService {

	

	List<SongDTO> getAllSongs(int songId);

	int getCountofSongs(int albumId);

	List<AlbumDTO> getallAlbums();

	

	String addSong(SongDTO songDto);

	
}
