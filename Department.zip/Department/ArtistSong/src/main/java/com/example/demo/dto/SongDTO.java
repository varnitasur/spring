package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class SongDTO {
	
	private int songId;
	private String songName;
	@JsonIgnore
	private ArtistDTO artist;
	@JsonIgnore
	private AlbumDTO album;
	public int getSongId() {
		return songId;
	}
	public void setSongId(int songId) {
		this.songId = songId;
	}
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}
	public ArtistDTO getArtist() {
		return artist;
	}
	public void setArtist(ArtistDTO artist) {
		this.artist = artist;
	}
	public AlbumDTO getAlbum() {
		return album;
	}
	public void setAlbum(AlbumDTO album) {
		this.album = album;
	}
	
	

}
