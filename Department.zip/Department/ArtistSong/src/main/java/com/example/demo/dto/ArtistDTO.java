package com.example.demo.dto;

import java.util.List;

public class ArtistDTO {

	private int artistId;
	private String artistName;
	private List<SongDTO> songList;
	
	public int getArtistId() {
		return artistId;
	}
	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}
	public String getArtistName() {
		return artistName;
	}
	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}
	public List<SongDTO> getSongList() {
		return songList;
	}
	public void setSongList(List<SongDTO> songList) {
		this.songList = songList;
	}
	
	
}
