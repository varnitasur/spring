package com.example.demo.exception;

public class ErrorConstant {
	
	public static final String NoSongsFound="no song found in album";

}
