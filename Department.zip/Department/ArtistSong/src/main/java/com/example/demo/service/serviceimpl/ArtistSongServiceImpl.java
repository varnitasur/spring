package com.example.demo.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.service.spi.ServiceException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.AlbumDTO;
import com.example.demo.dto.ArtistDTO;
import com.example.demo.dto.SongDTO;
import com.example.demo.entity.Album;
import com.example.demo.entity.Artist;
import com.example.demo.entity.Song;
import com.example.demo.exception.ErrorConstant;
import com.example.demo.repository.AlbumRepository;
import com.example.demo.repository.ArtistRepository;
import com.example.demo.repository.SongRepository;
import com.example.demo.service.ArtistSongService;
@Service
public class ArtistSongServiceImpl implements ArtistSongService {

	ModelMapper modelmapper = new ModelMapper();
	
	@Autowired
	AlbumRepository albumRepose;
	@Autowired
	ArtistRepository artistRepose;
	@Autowired
	SongRepository songRepose;
	
	@Override
	public String addSong(SongDTO songDto) {
		int count=0,flag=0;
		Song song= convertDTOtoEntity(songDto);
		Album album=song.getAlbum();
		List<Album> albums= albumRepose.findAll();
		if(album!=null && albums !=null) {
			for (Album album2 : albums) {
				if(album2.getAlbumId()==album.getAlbumId()) {
					count=1;
					break;
				}
			}
		}
		if(count==0) {
			albumRepose.save(album);
			
		}
		Artist artist=song.getArtist();
		List<Artist> artists= artistRepose.findAll();
		if(artist!=null && artists !=null) {
			for (Artist artist2 : artists) {
				if(artist2.getArtistId()==artist.getArtistId()) {
					flag=1;
					break;
				}
			}
			
		}
		if(flag==0) {
			artistRepose.save(artist);
			
		}
		song.setAlbum(album);
		song.setArtist(artist);
		songRepose.save(song);
		return "Success";
	}

	private Artist convertDTOtoEntity(ArtistDTO artistDTO) {
		
		return modelmapper.map(artistDTO,Artist.class);
	}

	@Override
	public List<SongDTO> getAllSongs(int songId) throws ServiceException{
		Song song=null;
		Artist artist= null;
		if(!(songRepose.existsById(songId))) {
			throw new ServiceException(ErrorConstant.NoSongsFound);
		}
		else
		{
			song=songRepose.findById(songId).get();
			artist=artistRepose.findById(song.getArtist().getArtistId()).get();
		}
		List<Song> songs= songRepose.findAll();
		List<SongDTO> songsDtoList= new ArrayList<SongDTO>();
		for (Song song2 : songs) {
			if(song2.getArtist().getArtistId()== artist.getArtistId())
			{
				AlbumDTO albumDto= convertEntityToDTO(song2.getAlbum());
				SongDTO songDto= convertEntityToDTO(song2);
				songDto.setAlbum(albumDto);
				songsDtoList.add(songDto);
			}
		}
		return songsDtoList;
	}

	@Override
	public int getCountofSongs(int albumId) {
		Album newAlbum= albumRepose.findById(albumId).get();
		int count= newAlbum.getSongs().size();
		return count;
	}
	
	private AlbumDTO convertEntityToDTO(Album album) {
		return modelmapper.map(album,AlbumDTO.class);
		
	}
	
	@SuppressWarnings("unused")
	private ArtistDTO convertEntityToDTO(Artist artist) {
		return modelmapper.map(artist,ArtistDTO.class);
		
	}
	
	private SongDTO convertEntityToDTO(Song song) {
		return modelmapper.map(song,SongDTO.class);
		
	}
	
	private Album convertDTOtoEntity(AlbumDTO albumDto) {
		return modelmapper.map(albumDto,Album.class);
	}
	
//	private Artist convertDTOtoEntity(ArtistDTO artistDto) {
//		return modelmapper.map(artistDto,Artist.class);
//	}
	
	private Song convertDTOtoEntity(SongDTO songDto) {
		return modelmapper.map(songDto,Song.class);
	}

	@Override
	public List<AlbumDTO> getallAlbums() {
		List<Album> albumList=albumRepose.findAll();
		List<AlbumDTO> albumDTOlist= new ArrayList<AlbumDTO>();
		for (Album album2 : albumList) {
			AlbumDTO albumDto=modelmapper.map(album2,AlbumDTO.class);
			albumDTOlist.add(albumDto);
		}
		return albumDTOlist;
	}
}
