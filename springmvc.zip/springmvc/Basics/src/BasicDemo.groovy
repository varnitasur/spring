println "Hello World."

def x = 104
println x.getClass()
x = "Guru99"
println x.getClass()


def y = """Groovy
at
Guru99"""
println y

0.upto(4) {println "$it"}

5.times{println "$it"}


def z = ["Guru99", "is", "Best", "for", "Groovy"]
println z
z.add("Learning")
println(z.contains("is"))
println(z.get(2))
println(z.pop())


def w = [fName:'Jen', lName:'Cruise', sex:'F']
print w.get("lName")
