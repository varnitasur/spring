def myClosure = {
	println "My First Closure"
}
myClosure()

def myClosure1 = {
	a,b,c->
	y = a+b+c
	println y
}
myClosure1(1,2,3)

def employee = ["Ken" : 21, "John" : 25, "Sally" : 22];

for(emp in employee) {
 println(emp);
}