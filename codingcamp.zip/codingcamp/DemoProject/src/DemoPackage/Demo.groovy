package DemoPackage

println "Hello World."

def x = """Groovy
is 
scripti lang"""
println x

0.upto(10) { println("$it")  }

def y = ["Guru99", "is", "Best", "for", "Groovy"]
println y
y.add("Learning")
println(y.contains("is"))
println(y.get(2))
println(y.pop())
