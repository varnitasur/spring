package com.mindtree.brandmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrandmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrandmanagementApplication.class, args);
	}

}
