package com.example.mindtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeLabApplication.class, args);
	}

}
