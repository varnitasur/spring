package com.example.mindtree.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.entity.Branch;
import com.example.mindtree.entity.College;
import com.example.mindtree.exception.CollegeBranchApplicationException;
import com.example.mindtree.repository.BranchRepository;
import com.example.mindtree.repository.CollegeRepository;
import com.example.mindtree.service.BranchService;
@Service
public class BranchServiceImpl implements BranchService {

	@Autowired
	CollegeRepository collegeRepository;
	@Autowired
	BranchRepository branchRepository;
	
	@Override
	public void addBranches(int collegeId, Branch branch) throws CollegeBranchApplicationException {
		// TODO Auto-generated method stub
		College college = collegeRepository.getOne(collegeId);
		college.getBranches().add(branch);
		if (college.getBranches().size() <= college.getNumberOfBranch()) {
			collegeRepository.saveAndFlush(college);
		} else {
			throw new CollegeBranchApplicationException("Branch Limit Reached For This College:");
		}

	}

	@Override
	public List<Branch> getBranchByCollege(int collegeId) {
		College college = collegeRepository.getOne(collegeId);
		return college.getBranches();
	}

	@Override
	public Branch getBranchById(int branchId) {
	
		return branchRepository.getOne(branchId);
	}

	@Override
	public void updateBranch(Branch branch) {
		branchRepository.saveAndFlush(branch);

	}

}
