package com.example.mindtree.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.mindtree.entity.College;

@Service
public interface CollegeService {
	
	public void addCollege(College college);
	public List<College> getColleges();


}
