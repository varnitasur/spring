package com.example.mindtree.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.mindtree.entity.Branch;
import com.example.mindtree.exception.CollegeBranchApplicationException;

@Service
public interface BranchService {
	
	public void addBranches(int collegeId, Branch branch) throws CollegeBranchApplicationException ;

	public List<Branch> getBranchByCollege(int collegeId);

  	public Branch getBranchById(int branchId);

  	public void updateBranch(Branch branch);

}
