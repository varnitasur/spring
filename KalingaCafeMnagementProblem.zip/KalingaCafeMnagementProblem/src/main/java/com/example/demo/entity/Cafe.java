package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","Handler"})
public class Cafe {
	
	@Id
	private int cafeid;
	private String cafeName;
	private float cafeRevenue;
	@ManyToOne
	private CafeManager cafemanager;
	public Cafe() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cafe(int cafeid, String cafeName, float cafeRevenue, CafeManager cafemanager) {
		super();
		this.cafeid = cafeid;
		this.cafeName = cafeName;
		this.cafeRevenue = cafeRevenue;
		this.cafemanager = cafemanager;
	}
	public int getCafeid() {
		return cafeid;
	}
	public void setCafeid(int cafeid) {
		this.cafeid = cafeid;
	}
	public String getCafeName() {
		return cafeName;
	}
	public void setCafeName(String cafeName) {
		this.cafeName = cafeName;
	}
	public float getCafeRevenue() {
		return cafeRevenue;
	}
	public void setCafeRevenue(float cafeRevenue) {
		this.cafeRevenue = cafeRevenue;
	}
	public CafeManager getCafemanager() {
		return cafemanager;
	}
	public void setCafemanager(CafeManager cafemanager) {
		this.cafemanager = cafemanager;
	}
	
	
	

}
