package com.example.demo.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Cafe;
import com.example.demo.entity.CafeManager;
import com.example.demo.exception.NoSuchManagerFoundException;
import com.example.demo.service.serviceImpl.CafeManagementServiceImpl;

@RestController
public class DemoController {
	@Autowired
	CafeManagementServiceImpl cafeService;
	
	@PostMapping("/insertcafe")
	public String insertCafe(@RequestBody Cafe cafe) {
		
		cafeService.insertCafe(cafe);
		
		return "inserted";
		
	}
	@PostMapping("/insertcafedetails/{managerid}")
	public void insertcafe(@RequestBody List<Cafe> cafe, @PathVariable int managerid) {
		cafeService.insertcafe(cafe, managerid);
		
	}
	@GetMapping("/getcafedetails/{managerid}")
	public List<Cafe> getallcafe(@PathVariable int managerid){
		List<Cafe> result;
		try {
			result = cafeService.getallcafe(managerid);
			return result;
		} catch (NoSuchManagerFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return null;
		
		
	}
	@GetMapping("/getcafe/{caferevenue}")
	public List<Cafe> getallcafedetails(@PathVariable float caferevenue){
		List<Cafe> result=cafeService.getallcafedetails(caferevenue);
		
		return result;
		
	}
}
