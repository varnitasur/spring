package com.example.demo.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Cafe;
import com.example.demo.entity.CafeManager;
import com.example.demo.exception.NoSuchManagerFoundException;
import com.example.demo.repository.CafeManagerRepository;
import com.example.demo.repository.CafeRepository;
import com.example.demo.service.CafeManagementService;

@Service
public class CafeManagementServiceImpl implements CafeManagementService{

	@Autowired
	CafeRepository caferepose;
	
	@Autowired
	CafeManagerRepository cafemagaerrepose;
	
		@Override
		public void insertcafe(List<Cafe> cafe, int managerid) {
			List<CafeManager> res=cafemagaerrepose.findAll();
			for (CafeManager cafeManager : res)
			{
				
				if(managerid==cafeManager.getManageId())
				{
					cafeManager.getCafes().addAll(cafe);
					caferepose.saveAll(cafe);
				}
			} 
		
	}

	@Override
	public List<Cafe> getallcafe(int managerid) throws NoSuchManagerFoundException {
		CafeManager cafeManager=cafemagaerrepose.getOne(managerid);
		List<Cafe> result=new ArrayList<Cafe>();
		int count=0;
		if(managerid== cafeManager.getManageId())
		{
			List<Cafe> cafelist=cafeManager.getCafes();
			for (Cafe cafe : cafelist) {
				cafe.getCafeid();
				cafe.getCafeName();
				cafe.getCafeRevenue();
				result.add(cafe);
				count++;
			}
			
			
		}
		if(count==0)
		{
			throw new NoSuchManagerFoundException("manager is not present");
		}
		
		return result;
	}

	

	@Override
	public List<Cafe> getallcafedetails(float caferevenue)
	{
		List<Cafe> newcafe= new ArrayList<Cafe>();
		caferepose.findAll();
		
		List<Cafe> result= caferepose.getallcafedetails(caferevenue);
		
		return result;
		
	}

	@Override
	public String insertCafe(Cafe cafe) {
		caferepose.save(cafe);
		return "inserted";
	}
	
	

}
