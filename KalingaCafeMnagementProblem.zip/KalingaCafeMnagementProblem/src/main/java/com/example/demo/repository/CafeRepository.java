package com.example.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Cafe;

@Repository
public interface CafeRepository  extends JpaRepository<Cafe, Integer>{

	@Transactional
	@Modifying
	@Query(value = "select * from cafe where cafe_revenue>?", nativeQuery=true)
	public List<Cafe> getallcafedetails(float caferevenue);
}
