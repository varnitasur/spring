package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Cafe;
import com.example.demo.entity.CafeManager;
import com.example.demo.exception.NoSuchManagerFoundException;

public interface CafeManagementService {

	public String insertCafe(Cafe cafe);
	public List<Cafe> getallcafe(int managerid) throws NoSuchManagerFoundException;
	public List<Cafe> getallcafedetails(float caferevenue);
	void insertcafe(List<Cafe> cafe, int managerid);
}
