package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","Handler"})
public class CafeManager {
	@Id
	private int manageId;
	private String managerName;
	private int managerSalary;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "cafemanager")
	@JsonBackReference
	private List<Cafe> cafes;
	public CafeManager() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CafeManager(int manageId, String managerName, int managerSalary, List<Cafe> cafes) {
		super();
		this.manageId = manageId;
		this.managerName = managerName;
		this.managerSalary = managerSalary;
		this.cafes = cafes;
	}

	public int getManageId() {
		return manageId;
	}
	public void setManageId(int manageId) {
		this.manageId = manageId;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public int getManagerSalary() {
		return managerSalary;
	}
	public void setManagerSalary(int managerSalary) {
		this.managerSalary = managerSalary;
	}
	public List<Cafe> getCafes() {
		return cafes;
	}
	public void setCafes(List<Cafe> cafes) {
		this.cafes = cafes;
	}
	
	

}
